export class Clients {
    constructor (
    public ClientName:string,
    public ClientSurname:string,
    public ClientFiscal:string,
    public ClientContact:string,
    public ClientContactAddress:string,
    public ClientContactEmail:string,
    public ClientContactPhone:string
    ){}
}
