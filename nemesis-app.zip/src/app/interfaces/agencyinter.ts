export interface Agencyinter {

    id:number,
    name:string,
    address:string,
    managerId:string,
    vat:string,
    email:string,
    phone:string,
    certification:string, 
    customerId:string,
    moreInfo:string,
    ids:string,
    version:number,

}
