import { Clients } from './clients';

describe('Clients', () => {
  it('should create an instance', () => {
    expect(new Clients()).toBeTruthy();
  });
});
