export class Agency {
    constructor (
        // public id:number,
        public name:string,
        public address:string,
        public managerId:string,
        public vat:string,
        public email:string,
        public phone:string,
        public certification:string, 
        public customerId:string,
        public moreInfo:string,
        public ids:string,
        public version:number,
        ){}
}