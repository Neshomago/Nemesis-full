export class Customer {
        constructor(
            // public id:number,
            public name:string,
            public address:string,
            public vat:string,
            public email:string,
            public phone:string,
            public ids:string,
            public version:number,
            ){}
}
